#pragma once
#include "Animal.h"


void info(const Animal& a) {
	cout << endl << string(42, '-') 
		 << "\nInfo.h: " << sizeof(a) << endl 
		 << string(42, '-') << endl << endl;
}