#pragma once
#include <iostream>
#include <string>
#include <Windows.h>

using namespace std;


class Animal {
private:
    int age;
    int area;
public:
    string name;

    Animal(string _name);
    Animal(string _name, int _age);
    Animal(string _name, int _age, int _area);

    void get_age();
    void get_area();
    void get_all();
};