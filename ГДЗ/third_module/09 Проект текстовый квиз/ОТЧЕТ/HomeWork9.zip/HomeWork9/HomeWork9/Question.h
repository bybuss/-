#pragma once
#include <iostream>
#include <string>
#include <Windows.h>
#include <vector>
using namespace std;

class Question {
private:
	int correct_id;
public:
	string theme;
	vector<string> answers;

	Question(string _theme, vector<string> _answers, int _correct_id);

	bool check_answer(int user_answer);
	void print_question();
	int get_answer();
};
