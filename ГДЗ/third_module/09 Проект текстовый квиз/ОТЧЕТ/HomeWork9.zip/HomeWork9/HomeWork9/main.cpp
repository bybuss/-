#include "Question.h"
#include "Quiz.h"
#include "Data.h"


int main() {
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	Quiz quiz(qsts);
	quiz.start();
}

