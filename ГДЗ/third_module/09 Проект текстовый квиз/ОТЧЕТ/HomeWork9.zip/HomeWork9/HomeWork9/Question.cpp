#include "Question.h" 

Question::Question(string _theme, vector<string> _answers, int _correct_id) :
	theme(_theme), answers(_answers), correct_id(_correct_id) {}

bool Question::check_answer(int user_answer) {
	return user_answer == this->correct_id;
}

void Question::print_question() {
	cout << theme << endl;
	for (int i = 0; i < this->answers.size(); i++) {
		cout << answers[i] << endl;
	}
}

int Question::get_answer() {
	return correct_id;
}