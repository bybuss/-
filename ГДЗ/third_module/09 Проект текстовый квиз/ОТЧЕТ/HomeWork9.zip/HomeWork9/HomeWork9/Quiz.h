#pragma once
#include "Question.h" 
#include <vector>
#include <string>
using namespace std;

class Quiz {
private:
	vector<Question> questions;
public:
	string username;
	int score;

	Quiz(vector<Question> _questions);

	void start();
};

